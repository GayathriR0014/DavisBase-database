package edu.db;

public class SerialCode {
	byte typeCode;
	byte length;

	public SerialCode(int typeCode, int length) {
		super();
		this.typeCode = (byte) typeCode;
		this.length = (byte) length;
	}
}
