package edu.db;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

public class QueryResult {

	private static final int COLUMN_WIDTH = 150;

	public static final int STRING_GROUP = 1;

	public static final int INTEGER_GROUP = 2;

	public static final int DOUBLE_GROUP = 3;

	public static final int DATETIME_GROUP = 4;

	public static final int BOOLEAN_GROUP = 5;

	public static final int OTHER = 0;

	static Map<String, Integer> sqlTypes;

	static {
		Map<String, Integer> aMap = new HashMap<>();
		aMap.put("NULL TINYINT", Types.TINYINT);
		aMap.put("NULL SMALLINT", Types.SMALLINT);
		aMap.put("NULL INT", Types.INTEGER);
		aMap.put("NULL DOUBLE", Types.DOUBLE);
		aMap.put("TINYINT", Types.TINYINT);
		aMap.put("SMALLINT", Types.SMALLINT);
		aMap.put("INT", Types.INTEGER);
		aMap.put("BIGINT", Types.BIGINT);
		aMap.put("REAL", Types.REAL);
		aMap.put("DOUBLE", Types.DOUBLE);
		aMap.put("DATETIME", Types.DATE);
		aMap.put("DATE", Types.DATE);
		aMap.put("TEXT", Types.VARCHAR);
		sqlTypes = Collections.unmodifiableMap(aMap);
	}


	private static class Field {

		private String label;

		private String type;

		private String typeName;

		private int width = 0;

		private List<String> values = new ArrayList<>();

		private String justifyFlag = "";

		private int typeCategory = 0;

		public Field(String label, String type, String typeName) {
			this.label = label;
			this.type = type;
			this.typeName = typeName;
		}

		public String getLabel() {
			return label;
		}

		public String getType() {
			return type;
		}

		public String getTypeName() {
			return typeName;
		}

		public int getWidth() {
			return width;
		}

		public void setWidth(int width) {
			this.width = width;
		}

		public void addValue(String value) {
			values.add(value);
		}

		public String getValue(int i) {
			return values.get(i);
		}

		public String getJustifyFlag() {
			return justifyFlag;
		}

		public void justifyLeft() {
			this.justifyFlag = "-";
		}

		public int getTypeCategory() {
			return typeCategory;
		}

		public void setTypeCategory(int typeCategory) {
			this.typeCategory = typeCategory;
		}
	}

	public static void printQueryResult(List<List<Column>> resultSet, List<List<Column>> columnss, String tableName,
			List<Integer> ordinalPostions) {
		int maxStringColWidth = COLUMN_WIDTH;


		int columnCount = columnss.size();


		List<Field> fields = new ArrayList<>(columnCount);


		List<String> tableNames = new ArrayList<>();
		tableNames.add(tableName);

			if (columnCount > 1)
			for (int i = 0; i < columnCount; i++) {
				Field c = new Field(columnss.get(i).get(2).column, columnss.get(i).get(3).column,
						columnss.get(i).get(3).column);
				c.setWidth(c.getLabel().length());
				c.setTypeCategory(getGroup(c.getType()));
				fields.add(c);

			}
		else {
			Field c = new Field(columnss.get(0).get(0).column, "TEXT", "TEXT");
			c.setWidth(c.getLabel().length());
			c.setTypeCategory(getGroup(c.getType()));
			fields.add(c);
		}

		int rowCount = 0;
		for (List<Column> tuple : resultSet) {
			for (int i = 0; i < columnCount; i++) {
				Field c = fields.get(i);
				String value = null;
				int category = c.getTypeCategory();

				if (category == OTHER) {

					value = "(" + c.getTypeName() + ")";

				} else {
					value = tuple.get(i).column == null ? "NULL" : tuple.get(i).column;
				}
				switch (category) {
				case DOUBLE_GROUP:


					if (!value.equals("NULL")) {
						Double dValue = Double.parseDouble(tuple.get(i).column);
						value = String.format("%.3f", dValue);
					}
					break;

				case STRING_GROUP:

					c.justifyLeft();

					if (value.length() > maxStringColWidth) {
						value = value.substring(0, maxStringColWidth - 3) + "...";
					}
					break;
				}

				// Adjust the column width
				c.setWidth(value.length() > c.getWidth() ? value.length() : c.getWidth());
				c.addValue(value);
			}
			rowCount++;

		}

		StringBuilder strToPrint = new StringBuilder();
		StringBuilder rowSeparator = new StringBuilder();


		int j = 1;

		for (Field c : fields) {
			if (ordinalPostions == null || ordinalPostions.contains(j)) {
				int width = c.getWidth();

				// Center the column label
				String toPrint;
				String name = c.getLabel();
				int diff = width - name.length();

				if ((diff % 2) == 1) {
					width++;
					diff++;
					c.setWidth(width);
				}

				int paddingSize = diff / 2;
				String padding = new String(new char[paddingSize]).replace("\0", " ");

				toPrint = "| " + padding + name + padding + " ";

				strToPrint.append(toPrint);

				rowSeparator.append("+");
				rowSeparator.append(new String(new char[width + 2]).replace("\0", "-"));
			}
			j++;
		}

		String lineSeparator = System.getProperty("line.separator");

		lineSeparator = lineSeparator == null ? "\n" : lineSeparator;

		rowSeparator.append("+").append(lineSeparator);

		strToPrint.append("|").append(lineSeparator);
		strToPrint.insert(0, rowSeparator);
		strToPrint.append(rowSeparator);

		StringJoiner sj = new StringJoiner(", ");
		for (String name : tableNames) {
			sj.add(name);
		}

		// Print out the formatted column labels
		System.out.print(strToPrint.toString());

		String format;

		// Print out the rows
		j = 1;
		for (int i = 0; i < rowCount; i++) {
			for (Field c : fields) {
				if (ordinalPostions == null || ordinalPostions.contains(j)) {

					// format string like: "%-60s"
					format = String.format("| %%%s%ds ", c.getJustifyFlag(), c.getWidth());
					System.out.print(String.format(format, c.getValue(i)));
				}
				j++;
			}
			j = 1;
			System.out.println("|");
			System.out.print(rowSeparator);
		}
		System.out.println(resultSet.size() + " rows in set");
		System.out.println();

	}

	private static int getGroup(String type) {
		switch (sqlTypes.get(type)) {
		case Types.BIGINT:
		case Types.TINYINT:
		case Types.SMALLINT:
		case Types.INTEGER:
			return INTEGER_GROUP;

		case Types.REAL:
		case Types.DOUBLE:
		case Types.DECIMAL:
			return DOUBLE_GROUP;

		case Types.DATE:
			return DATETIME_GROUP;

		case Types.VARCHAR:
			return STRING_GROUP;

		default:
			return OTHER;
		}
	}
}
