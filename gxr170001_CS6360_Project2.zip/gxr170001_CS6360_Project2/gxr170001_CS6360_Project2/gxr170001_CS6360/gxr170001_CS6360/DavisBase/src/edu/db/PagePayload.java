package edu.db;

import java.util.List;

public class PagePayload {
	byte noColumns;
	byte serialCodes[];
	List<Column> columnData;
}
